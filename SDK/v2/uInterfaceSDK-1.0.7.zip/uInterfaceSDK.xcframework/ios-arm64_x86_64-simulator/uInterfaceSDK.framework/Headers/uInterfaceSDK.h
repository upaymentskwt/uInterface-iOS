//
//  uInterfaceSDK.h
//  uInterfaceSDK
//
//  Created by user on 06/05/24.
//

#import <Foundation/Foundation.h>

//! Project version number for uInterfaceSDK.
FOUNDATION_EXPORT double uInterfaceSDKVersionNumber;

//! Project version string for uInterfaceSDK.
FOUNDATION_EXPORT const unsigned char uInterfaceSDKVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <uInterfaceSDK/PublicHeader.h>
